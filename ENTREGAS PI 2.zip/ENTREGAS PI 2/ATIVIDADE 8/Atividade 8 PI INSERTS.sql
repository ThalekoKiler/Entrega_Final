use iot;

-- INSERTS dos locais!!
INSERT INTO local (nome, setor, descricao) VALUES
('Galpao Principal A', 'Estoque Seco', 'Area de armazenamento geral de produtos não-refrigerados.'),
('Camara Fria 03', 'Estoque Refrigerado', 'Unidade de refrigeração para produtos perecíveis (Lat. 1).'),
('Area de Expedicao', 'Logistica', 'Area de preparacao de pedidos para transporte.');

-- INSERTS dos funcionários!!
INSERT INTO funcionario (nome, telefone, email, cpf) VALUES
('Ana Clara Lima', '5511987654321', 'ana.lima@packbag.com.br', '123.456.789-01'),
('Bruno Mendes Silva', '5511912345678', 'bruno.silva@packbag.com.br', '987.654.321-09');

-- INSERTS dos sensores!!
INSERT INTO sensor (local_idlocal, funcionario_idfuncionario, tipo, modelo, status, dataInstalacao) VALUES
-- Sensor 1: Galpão Principal A (Local ID 1), Responsável Ana (Func ID 1)
(1, 1, 'Temperatura e Umidade', 'DHT22', 'OK', '2025-10-01'),
-- Sensor 2: Câmara Fria 03 (Local ID 2), Responsável Bruno (Func ID 2)
(2, 2, 'Temperatura e Umidade', 'DHT22', 'OK', '2025-10-05'),
-- Sensor 3: Area de Expedição (Local ID 3), Responsável Ana (Func ID 1)
(3, 1, 'Temperatura e Umidade', 'DHT22', 'OK', '2025-10-10');

-- INSERTS dos medicao!!
INSERT INTO medicao (idsensor, dataHora, dataData, frequencia, valor) VALUES
-- Leituras do Sensor 1 (Galpão, temp ambiente)
(1, '2025-10-16 09:00:00', '2025-10-16', '15 min', '25.5C / 60.0%'),
(1, '2025-10-16 09:15:00', '2025-10-16', '15 min', '25.4C / 60.5%'),

-- Leituras do Sensor 2 (Câmara Fria, temp baixa)
(2, '2025-10-16 09:05:00', '2025-10-16', '15 min', '4.1C / 78.2%'),
(2, '2025-10-16 09:20:00', '2025-10-16', '15 min', '4.2C / 78.5%'),

-- Leituras do Sensor 3 (Expedição, temp ambiente)
(3, '2025-10-16 09:10:00', '2025-10-16', '15 min', '26.1C / 58.0%'),
(3, '2025-10-16 09:25:00', '2025-10-16', '15 min', '26.0C / 58.1%');

SELECT
    -- Dados da Medição (O que foi lido)
    M.dataHora AS "Data e Hora da Leitura",
    M.valor AS "Valor (T/U)",
    M.frequencia AS "Frequência de Envio",
    
    -- Dados da Localização (Onde foi lido)
    L.nome AS "Local",
    L.setor AS "Setor",
    L.descricao AS "Descrição do Local",
    
    -- Dados do Sensor (Qual dispositivo)
    S.idsensor AS "ID Sensor",
    S.modelo AS "Modelo Sensor",
    S.status AS "Status Sensor",
    
    -- Dados do Funcionário (Quem é o responsável)
    F.nome AS "Responsável Manutenção",
    F.email AS "Email Responsável"
    
FROM
    medicao AS M -- Tabela base, começando pelas medições
    
INNER JOIN 
    sensor AS S ON M.idsensor = S.idsensor -- Liga Medição ao Sensor
    
INNER JOIN 
    local AS L ON S.local_idlocal = L.idlocal -- Liga Sensor à Localização
    
INNER JOIN 
    funcionario AS F ON S.funcionario_idfuncionario = F.idfuncionario -- Liga Sensor ao Funcionário
    
ORDER BY
    M.dataHora DESC; -- Ordena da mais recente para a mais antiga