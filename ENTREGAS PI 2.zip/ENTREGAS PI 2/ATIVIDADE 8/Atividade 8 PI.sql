CREATE DATABASE iot;
USE iot;

CREATE TABLE local (
    idlocal INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(45) NOT NULL UNIQUE,
    setor VARCHAR(45),
    descricao VARCHAR(60)
);

CREATE TABLE funcionario (
    idfuncionario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(45) NOT NULL,
    telefone VARCHAR(45),
    email VARCHAR(100) UNIQUE,
    cpf VARCHAR(25) UNIQUE -- Geralmente, o CPF é único
);

CREATE TABLE sensor (
    idsensor INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(45), 
    modelo VARCHAR(45), 
    status VARCHAR(4) NOT NULL DEFAULT 'OK',
    dataInstalacao DATE NOT NULL,
    funcionario_idfuncionario INT, 
    local_idlocal INT NOT NULL,     
    FOREIGN KEY (funcionario_idfuncionario) REFERENCES funcionario(idfuncionario),
    FOREIGN KEY (local_idlocal) REFERENCES local(idlocal)
);

CREATE TABLE medicao (
    idmedicao INT AUTO_INCREMENT PRIMARY KEY,
    idsensor INT NOT NULL,        
    dataHora DATETIME NOT NULL,
    dataData DATE,                 
    frequencia VARCHAR(45),        
    valor VARCHAR(20) NOT NULL,    
    FOREIGN KEY (idsensor) REFERENCES sensor(idsensor)
);

ALTER TABLE sensor
ADD COLUMN medicao_ultimedicao INT;

ALTER TABLE sensor
ADD constraint fk_ultima_medicao
foreign key (medicao_ultimedicao) REFERENCES medicao(idmedicao);